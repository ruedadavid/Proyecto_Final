# CesiumTaller05

## Esta práctica permite leer un archivo geojson, y visualizarlo utilizando un menú desarrollado y presnetado en el tutorial Sandbox.
### Se debe instalar en el direcotrio Apps del paquete de Cesium, se desarrollo bajo Ceium 1.44
